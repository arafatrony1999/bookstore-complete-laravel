
<?php $__env->startSection('content'); ?>
    <main class="admin_main">
        <div class="d-flex justify-content-center bs-spinner">
            <div class="spinner-border bs-spinner-border" role="status">
              <span class="sr-only">Loading...</span>
            </div>
        </div>

        <div class="addNewButton">
            <button id="addNewproduct" class="btn btn-primary">Add New</button>
        </div>

        <table class="table" id="productuserTable">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Book Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Image</th>
                    <th scope="col">Prokashoni</th>
                    <th scope="col">Writer</th>
                    <th scope="col">Catagory</th>
                    <th scope="col">Update</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>


            <tbody id="productTR">

            </tbody>
            
        </table>




        
        <!-- Modal -->
        <div class="modal fade" id="addNewproductModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <h2 class="p-3">Add New item</h2>
                        
                        <form id="productform_id" enctype="multipart/form-data">
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">বইয়ের নাম</label>
                                    <input type="text" id="productName" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">দাম</label>
                                    <input type="text" id="productPrice" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">ছবি</label>
                                    <input type="file" id="productImage" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">প্রকাশনী</label>
                                    <input type="text" id="productProkashoni" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">লেখক</label>
                                    <input type="text" id="productWriter" class="form-control" />
                                </div>
                            
                                <div class="form-group col">
                                    <label>ক্যাটাগরি</label>
                                    <select id="productCatagory" class="form-control">
                                        <option selected>ক্যাটাগরি...</option>
                                        <?php $__currentLoopData = $bishoy_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bishoy_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bishoy_name->bishoyName); ?>"><?php echo e($bishoy_name->bishoyName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            

                            <div class="modal-footer">
                                <div class="d-none">
                                    <p style="color: red">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        দুঃখিত। আবার চেষ্টা করুণ !
                                    </p>
                                </div>
                                <div width="100%" class="d-none">
                                    <p style="color: green">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        ডাটা সফল ভাবে ডাটাবেজে সংরক্ষিত করা হয়েছে ।
                                    </p>
                                </div>
                                <div class="flexLeft">
                                    <button data-id="" id="productAddBtn" type="button" class="get btn btn-success">Add</button>
                                    <button onclick="$('#addNewproductModal').modal('hide')" type="button" class="btn btn-primary" data-mdb-dismiss="modal">
                                        Cancle
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>





                
        <!--Update Modal -->
        <div class="modal fade" id="updateproductModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <h2 class="p-3">Add New item</h2>
                        
                        <form enctype="multipart/form-data">
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">বইয়ের নাম</label>
                                    <input type="text" id="productNameUpdate" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">দাম</label>
                                    <input type="text" id="productPriceUpdate" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">ছবি</label>
                                    <input type="file" id="productImageUpdate" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">প্রকাশনী</label>
                                    <input type="text" id="productProkashoniUpdate" class="form-control" />
                                </div>
                            </div>

                            <div class="showImageUpdateModal">
                                
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">লেখক</label>
                                    <input type="text" id="productWriterUpdate" class="form-control" />
                                </div>
                            
                                <div class="form-group col">
                                    <label>ক্যাটাগরি</label>
                                    <select id="productCatagoryUpdate" class="form-control">
                                        <option selected>ক্যাটাগরি...</option>
                                        <?php $__currentLoopData = $bishoy_name_update; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bishoy_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($bishoy_name->bishoyName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            <h2 class="d-none" id="getproductUpdateDataID"></h2>

                            <div class="modal-footer">
                                <div class="d-none" id="warningproductUpdate">
                                    <p style="color: red">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        দুঃখিত। আপনি কোনো ডাটা আপডেট করেননি ।
                                    </p>
                                </div>
                                <div width="100%" class="d-none" id="SuccessproductUpdate">
                                    <p style="color: green">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        আপডেট সফল হয়েছে ।
                                    </p>
                                </div>
                                <div class="flexLeft">
                                    <button data-id="" id="productUpdateBtn" type="button" class="get btn btn-success">Update</button>
                                    <button onclick="$('#updateproductModal').modal('hide')" type="button" class="btn btn-primary" data-mdb-dismiss="modal">
                                        Cancle
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        





        
        <div class="modal fade" id="productDeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <h2 class="p-3">Are you sure you want to delete this data?</h2>
                        <h2 class="d-none" id="productDeleteIDget"></h2>
                    </div>
                    <div class="modal-footer">
                        <button data-id="" id="productDeleteIDwork" type="button" class="get btn btn-danger">Delete</button>
                        <button onclick="$('#productDeleteModal').modal('hide')" type="button" class="btn btn-success" data-mdb-dismiss="modal">
                            Cancle
                        </button>
                    </div>
                </div>
            </div>
        </div>
        


        <!-- Catagory2 sorry modal -->
        <div class="modal fade" id="productsorryMessege" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <button onclick="$('#productsorryMessege').modal('hide')" type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close" ></button>
                    </div>
                    <div class="modal-body sorry-modal-body">

                    </div>
                    <div class="modal-footer">
                        <button type="button" id="refreshproductPage" class="btn btn-secondary" data-mdb-dismiss="modal">
                        Try Again
                        </button>
                        <button onclick="$('#productsorryMessege').modal('hide')" type="button" class="btn btn-primary">Cancle</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Catagory2 sorry modal -->


    </main>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

<script>
    getproductData();


    function getproductData(){
    $('#productUpdateBtn').html("Update");
    $('#productDeleteIDwork').html("Delete");
    
    axios.get('/getproductData')
    .then(function(response){

        var jsonData=response.data;

        $('#productTR').empty();
        $.each(jsonData,function(i){
            $('<tr>').html(
            "<td>"+jsonData[i].id+"</td>"+
            "<td>"+jsonData[i].bookName+"</td>"+
            "<td>৳"+jsonData[i].bookPrice+".00</td>"+
            "<td><img width='50px' src='"+jsonData[i].productImage+"'></td>"+
            "<td>"+jsonData[i].bookProkashoni+"</td>"+
            "<td>"+jsonData[i].bookWriter+"</td>"+
            "<td>"+jsonData[i].bookCatagory+"</td>"+
            "<td><button type='button' class='btn btn-success catchproductUpdateID' id='catchproductUpdateID' data-id="+jsonData[i].id+">"+"Update</button></td>"+
            "<td><button type='button' class='btn btn-danger catchproductDeleteID' id='catchproductDeleteID' data-id="+jsonData[i].id+">"+"Delete</button></td>"
            ).appendTo('#productTR');
        });

        $('.bs-spinner').addClass('d-none');


        // append id for delete book fair item 
        $('.catchproductDeleteID').on('click',function(){
            var deleteID = $(this).data('id');
            $('#productDeleteModal').modal('show');
            $('#productDeleteIDget').html(deleteID);
        });
        // append id for delete book fair item 


        
        // append id for update book fair item 
        $('.catchproductUpdateID').on('click',function(){
            if(!$('#warningproductUpdate').hasClass('d-none')){
                $('#warningproductUpdate').addClass('d-none');
            }
            if(!$('#SuccessproductUpdate').hasClass('d-none')){
                $('#SuccessproductUpdate').addClass('d-none');
            }
            var updateIDget = $(this).data('id');
            var updateURL = '/productUpdateURL';
            var updateID = {updateID:updateIDget};
            
            axios.post(updateURL,updateID)
            .then(function(response){
                var jsonDataUpdate = response.data;
                $('#productNameUpdate').val(jsonDataUpdate[0].bookName);
                $('#productPriceUpdate').val(jsonDataUpdate[0].bookPrice);
                $('#productProkashoniUpdate').val(jsonDataUpdate[0].bookProkashoni);
                $('#productWriterUpdate').val(jsonDataUpdate[0].bookWriter);
                $('#productCatagoryUpdate').val(jsonDataUpdate[0].bookCatagory);

                var updateImage = "<img height='80px' src='"+jsonDataUpdate[0].productImage+"'>";
                $('.showImageUpdateModal').html(updateImage);
        
                $('#getproductUpdateDataID').html(jsonDataUpdate[0].id);
                $('#updateproductModal').modal('show');
            })
            .catch(function(error){
                alert('fuck');
            });
        });
        // append id for update book fair item 

        $('#productuserTable').DataTable();
        $('.dataTables_length').addClass('bs-select');
        
    })
    .catch(function(error){
        var sorryModalText = "দুঃক্ষিত ! পেইজ রিফ্রেশ করুণ।";
        $('.sorry-modal-body').html(sorryModalText);
        $('#productsorryMessege').modal('show');
    });
}

// Book fair delete item function 
$('#productDeleteIDwork').on('click',function(){
    var deleteSpinner = "<div class='d-flex justify-content-center'><div class='spinner-border spinner-border-sm' role='status'></div></div>";
    $('#productDeleteIDwork').html(deleteSpinner);


    var productDeleteIDget = $('#productDeleteIDget').html();

    var productDeleteID = {productDeleteIDget:productDeleteIDget}
    var productDeleteURL = '/productDeleteURL';

    axios.post(productDeleteURL,productDeleteID)
    .then(function(response){
        if(response.data==1){
            getproductData();
            $('#productDeleteModal').modal('hide');
        }
        else{
            $('.modal-body').html("Something went wrong!");
        }
    })
    .catch(function(error){
        $('.modal-body').html("Something went wrong!");
    });
});


// Book Fair update function 
$('#productUpdateBtn').on('click',function(){
    var updateSpinner = "<div class='d-flex justify-content-center'><div class='spinner-border spinner-border-sm' role='status'></div></div>";
    $('#productUpdateBtn').html(updateSpinner);
    
    var productUpdateIDget = $('#getproductUpdateDataID').html();

    
    var bookNameUpdate = $('#productNameUpdate').val();

    var bookPriceUpdate = $('#productPriceUpdate').val();

    var productImageGetUpdate = $('#productImageUpdate').prop('files')[0];
    var productImageUpdate = new FormData();
    productImageUpdate.append('photoUpdate',productImageGetUpdate);

    var bookProkashoniUpdate = $('#productProkashoniUpdate').val();
    var bookWriterUpdate = $('#productWriterUpdate').val();
    var bookCatagoryUpdate = $('#productCatagoryUpdate').val();

    var productFinalUpdateURL = '/productFinalUpdateURL';
    var sendproductObject = {
        productUpdateID:productUpdateIDget,
        bookNameUpdate:bookNameUpdate,
        bookPriceUpdate:bookPriceUpdate,
        bookProkashoniUpdate:bookProkashoniUpdate,
        bookWriterUpdate:bookWriterUpdate,
        bookCatagoryUpdate:bookCatagoryUpdate
    };


    axios.post(productFinalUpdateURL,sendproductObject)
    .then(function(response){
        if(response.data==1){
            if(productImageGetUpdate==null){
                $('#SuccessproductUpdate').removeClass('d-none');
                $('#updateproductModal').modal('hide');
                getproductData();
            }
            else{
                var productImageFinalUpdateURL = '/productImageFinalUpdateURL';
                axios.post(productImageFinalUpdateURL,productImageUpdate)
                .then(function(response){
                    $('#SuccessproductUpdate').removeClass('d-none');
                    $('#updateproductModal').modal('hide');
                    getproductData();
                })
                .catch(function(error){
                    alert('Image update failed!');
                });
            }
        }else{
            $('#warningproductUpdate').removeClass('d-none');
            // $('#productUpdateBtn').html("Update");
        }
    })
    .catch(function(error){
        $('#warningproductUpdate').removeClass('d-none');
        // $('#productUpdateBtn').html("Update");
    });
});
// Book Fair update function

$('#refreshproductPage').on('click',function(){
    location.reload();
});




$(document).ready(function(){

$('#addNewproduct').on('click',()=>{
    $('#productform_id').trigger("reset");
    $('#productAddBtn').html("Add");
    $('#addNewproductModal').modal('show');
});


$('#productAddBtn').on('click',()=>{
    var addNewSpinner = "<div class='d-flex justify-content-center'><div class='spinner-border spinner-border-sm' role='status'></div></div>";
    $('#productAddBtn').html(addNewSpinner);


    var bookName1 = $('#productName').val();

    var bookPrice1 = $('#productPrice').val();

    var productImageGet = $('#productImage').prop('files')[0];
    var productImage = new FormData();
    productImage.append('photo',productImageGet);

    var bookProkashoni1 = $('#productProkashoni').val();
    var bookWriter1 = $('#productWriter').val();
    var bookCatagory1 = $('#productCatagory').val();

    var productData = {bookName1:bookName1,bookPrice1:bookPrice1,bookProkashoni1:bookProkashoni1,bookWriter1:bookWriter1,bookCatagory1:bookCatagory1}
    var productUrl = '/productAddNew';

    alert(bookCatagory1);
    

    axios.post(productUrl,productData)
    .then(function(response){
        if(response.data==1){
            // var checkAddImageExistence = Object.keys('photo').length;
            if(productImageGet==null){
                $('#addNewproductModal').modal('hide');
                getproductData();
            }
            else{
                var productImageUrl = '/productImageUrl';
                axios.post(productImageUrl,productImage)
                .then(function(response){
                    if(response.data==1){
                        $('#addNewproductModal').modal('hide');
                        getproductData();
                    }
                })
                .catch(function(error){
                    alert("image upload failed");
                });
            }
            $('#addNewproductModal').modal('hide');
            getproductData();
        }
        else{
            $('#productAddBtn').html("Add");
            $('#SuccessAdd').removeClass('d-none');
            getproductData();
        }
    })
    .catch(function(error){
        $('#productAddBtn').html("Add");
        $('#SuccessAdd').removeClass('d-none');
        getproductData();
    });

});
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/adminproduct.blade.php ENDPATH**/ ?>