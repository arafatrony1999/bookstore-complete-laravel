

<?php $__env->startSection('content'); ?>


    <section>
        <div class="page-title">
            <h1>Profile</h1>
            <div class="page-dir">
                <span>home</span>
                <span> / </span>
                <span class="current-pag">My Orders</span>
            </div>
        </div>
    </section>


    <?php $__currentLoopData = $cookieCurrentUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cookieCurrentUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section class="container">
            <div class="profile-section">
                <div class="profile-left">
                    <div class="profile-main">
                        <div class="profile-image">
                            <img src="<?php echo e(URL::asset('images/avatar.png')); ?>" alt="">
                        </div>
                        <div class="profile-other">
                            <h4>Hello,</h4>
                            <h1><?php echo e($cookieCurrentUser->userFirstName); ?> <?php echo e($cookieCurrentUser->userLastName); ?></h1>
                        </div>
                    </div>
                    <div class="profile-catagory">
                        <a href="/profile">My Account</a>
                        <a href="/profile/my-orders">My Orders</a>
                        <a href="/cart">My Cart items</a>
                        <a href="/profile/my-wishlist" class="an-active">My Wishlist</a>
                        <a href="#">My Reviews</a>
                        <a href="#">My Account</a>
                    </div>
                    <a href="/signout" class="last-anchor"><span>Sign Out</span></a>
                </div>
                <div class="profile-right">
                    <h2>My Wishlist</h2>
                    <div class="wishlist-items">
                        <?php $__currentLoopData = $wish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $wishlistItems = App\Models\product_modal::where('id','=',$wish->bookID)->get();
                            ?>
                            <?php $__currentLoopData = $wishlistItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlistItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="right-items-single-card">
                                    <div class="product-display-img">
                                        <img src="<?php echo e($wishlistItems->productImage); ?>" alt="Card image cap">
                                        <div class="product-cart-button">
                                            <a href="/product/product_id=<?php echo e($wishlistItems->id); ?>" class="big-cart2">Quick View</a>
                                            <a href="#" class="small-cart2 openCartBookFair" data-id="<?php echo e($wishlistItems->id); ?>"><i class="fas fa-search"></i></a>
                                            <?php
                                                $sessionID = Cookie::get('uuid');
                                                $wish = App\Models\wishList::where('sessionORcookie','=',$sessionID)->where('bookID','=',$wishlistItems->id)->count();
                                            ?>
                                            <?php if($wish==1): ?>
                                                <a href="" class="small-cart small-wishlist active-wishlist" data-id="<?php echo e($wishlistItems->id); ?>"><i class="fas fa-heart"></i></a>
                                            <?php else: ?>
                                                <a href="" class="small-cart small-wishlist" data-id="<?php echo e($wishlistItems->id); ?>"><i class="fas fa-heart"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="name-and-price">
                                        <h5 class="card-title mt-4"><?php echo e($wishlistItems->bookName); ?></h5>
                                        <h3 class="price-tag"><?php echo e($wishlistItems->bookWriter); ?></h3>
                                        <h3 class="price-tag">৳ <?php echo e($wishlistItems->bookPrice); ?>.00</h3>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </section>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/my-wishlist.blade.php ENDPATH**/ ?>