
<?php $__env->startSection('content'); ?>
    <main class="admin_main">
        

        <div class="first-group">
            <form action="/adminImageUpload" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="adminImageUpload" id="">
                <button type="submit" class="btn btn-info">Upload</button>
            </form>
        </div>

        <div class="image-container">
            
        </div>

    </main>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/adminImages.blade.php ENDPATH**/ ?>