

<?php $__env->startSection('content'); ?>

    <section>
        <div class="page-title">
            <h1>Profile</h1>
            <div class="page-dir">
                <span>home</span>
                <span> / </span>
                <span class="current-pag">Profile</span>
            </div>
        </div>
    </section>


    <section class="container">
        <div class="profile-section">
            <div class="profile-left">
                <div class="profile-main">
                    <div class="profile-image">
                        <img src="images/avatar.png" alt="">
                    </div>
                    <div class="profile-other">
                        <h4>Hello,</h4>
                        <h1>Arafat Rony</h1>
                    </div>
                </div>
                <div class="profile-catagory">
                    <a href="#" class="an-active">My Account</a>
                    <a href="#">My Orders</a>
                    <a href="#">My Cart items</a>
                    <a href="#">My Wishlist</a>
                    <a href="#">My Reviews</a>
                    <a href="#">My Account</a>
                </div>
            </div>
            <div class="profile-right">
                <h2>Personal Information</h2>
                <div class="profile-form">
                    <form autocomplete="off" method="post" action="">
                        <input type="hidden" autocomplete="false" name="hidden">

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="firstName">First Name</label>
                                <input type="text" name="firstName" class="form-control" id="lastName"
                                    placeholder="First Name">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="lastName">Last Name</label>
                                <input type="text" name="lastName" class="form-control" id="lastName"
                                    placeholder="Last Name">
                            </div>
                        </div>
                        <label for="birthDate">Date of Birth</label>
                        <input class="form-control" type="date" name="dateOfBirth" placeholder="dd-mm-yyyy" value="1999-10-06"
                            min="1997-01-01" max="2030-12-31">
                            
                        <div class="form-group">
                            <label for="Phone">Phone</label>
                            <input type="text" class="form-control" name="phoneNumber" placeholder="Phone Number">
                        </div>
                        <div class="form-group">
                            <label for="Email">Email</label>
                            <input type="email" class="form-control" name="emailAddr" placeholder="Email Address">
                        </div>
                        <div class="form-group">
                            <label for="CompanyName">Company name (optional)</label>
                            <input type="text" name="CompanyName" class="form-control" id="CompanyName">
                        </div>
                        <div class="form-group">
                            <label for="countryName">Country</label>
                            <select autocomplete="country" id="select-Country" name="country" class="mdb-select md-form"
                                searchable="Search Country..">
                                <option value="">Select a Country...</option>
                                <option value="Argentina">Argentina</option>
                                <option value="Australia">Australia</option>
                                <option value="England">England</option>
                                <option value="USA">USA</option>
                                <option value="Bangladesh" selected>Bangladesh</option>
                                <option value="India">India</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Srilanka">Srilanka</option>
                                <option value="Afganistan">Afganistan</option>
                                <option value="Canada">Canada</option>
                                <option value="Japan">Japan</option>
                                <option value="Chaina">Chaina</option>
                                <option value="UAE">UAE</option>
                                <option value="Korea">Korea</option>
                                <option value="Nepal">Nepal</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="streerAddr">Street address</label>
                            <input type="text" class="form-control" id="streetAddr" name="streetAddr"
                                placeholder="House Number and street name">
                            <p></p>
                            <input type="text" class="form-control" id="streerAddr2"
                                placeholder="Apartment, suite, unit etc. (optional)">
                        </div>
                        <div class="form-group">
                            <label for="districtName">District</label>
                            <select autocomplete="off" id="selectDistrict" name="District" class="mdb-select md-form"
                                searchable="Search Country..">
                                <option value="">Select District...</option>
                                <option value="Barguna">Barguna</option>
                                <option value="Barisal">Barisal</option>
                                <option value="Bhola">Bhola</option>
                                <option value="Jhalokati">Jhalokati</option>
                                <option value="Patuakhali">Patuakhali</option>
                                <option value="Brahmanbaria">Brahmanbaria</option>
                                <option value="Chandpur">Chandpur</option>
                                <option value="Chittagong">Chittagong</option>
                                <option value="Dhaka" selected>Dhaka</option>
                                <option value="Comilla">Comilla</option>
                                <option value="Noakhali">Noakhali</option>
                                <option value="Feni">Feni</option>
                                <option value="Gazipur">Gazipur</option>
                                <option value="Munshiganj">Munshiganj</option>
                                <option value="Narayanganj">Narayanganj</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="inputAddress2">Town / City</label>
                            <input type="text" name="townOrCity" class="form-control" id="streerAddr3">
                        </div>
                        <div class="form-group">
                            <label for="Postcode">Postcode / ZIP (optional)</label>
                            <input type="text" name="zipCode" class="form-control" id="post-zip">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/profile.blade.php ENDPATH**/ ?>