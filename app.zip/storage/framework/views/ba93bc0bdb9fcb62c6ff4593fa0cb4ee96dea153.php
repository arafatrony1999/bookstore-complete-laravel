<form action="/import" enctype="multipart/form-data" method="post">
    <?php echo csrf_field(); ?>
    <input type="file" name="file" id="">
    <button type="submit">Submit</button>
</form>


<a href="/export" class="btn btn-primary">Export Excel</a><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/importPage.blade.php ENDPATH**/ ?>