
<?php $__env->startSection('content'); ?>
    <main class="admin_main">
        <div class="d-flex justify-content-center bs-spinner">
            <div class="spinner-border bs-spinner-border" role="status">
              <span class="sr-only">Loading...</span>
            </div>
        </div>

        <div class="addNewButton">
            <button id="addNewBookFair" class="btn btn-primary">Add New</button>
        </div>

        <table class="table" id="userTable">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Book Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Image</th>
                    <th scope="col">Prokashoni</th>
                    <th scope="col">Writer</th>
                    <th scope="col">Catagory</th>
                    <th scope="col">Update</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>


            <tbody id="bookFairTR">

            </tbody>
            
        </table>




        
        <!-- Modal -->
        <div class="modal fade" id="addNewBookFairModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <h2 class="p-3">Add New item</h2>
                        
                        <form id="form_id" enctype="multipart/form-data">
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">বইয়ের নাম</label>
                                    <input type="text" id="bookName" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">দাম</label>
                                    <input type="text" id="bookPrice" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">ছবি</label>
                                    <input type="file" id="bookImage" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">প্রকাশনী</label>
                                    <input type="text" id="bookProkashoni" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">লেখক</label>
                                    <input type="text" id="bookWriter" class="form-control" />
                                </div>
                            
                                <div class="form-group col">
                                    <label>ক্যাটাগরি</label>
                                    <select id="bookCatagory" class="form-control">
                                        <option selected>ক্যাটাগরি...</option>
                                        <?php $__currentLoopData = $bishoy_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bishoy_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value=""><?php echo e($bishoy_name->bishoyName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            

                            <div class="modal-footer">
                                <div class="d-none" id="warningAdd">
                                    <p style="color: red">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        দুঃখিত। আবার চেষ্টা করুণ !
                                    </p>
                                </div>
                                <div width="100%" class="d-none" id="AddUpdate">
                                    <p style="color: green">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        ডাটা সফল ভাবে ডাটাবেজে সংরক্ষিত করা হয়েছে ।
                                    </p>
                                </div>
                                <div class="flexLeft">
                                    <button data-id="" id="bookFairAddBtn" type="button" class="get btn btn-success">Add</button>
                                    <button onclick="$('#addNewBookFairModal').modal('hide')" type="button" class="btn btn-primary" data-mdb-dismiss="modal">
                                        Cancle
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>





                
        <!--Update Modal -->
        <div class="modal fade" id="updateBookFairModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <h2 class="p-3">Add New item</h2>
                        
                        <form enctype="multipart/form-data">
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">বইয়ের নাম</label>
                                    <input type="text" id="bookNameUpdate" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">দাম</label>
                                    <input type="text" id="bookPriceUpdate" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">ছবি</label>
                                    <input type="file" id="bookImageUpdate" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">প্রকাশনী</label>
                                    <input type="text" id="bookProkashoniUpdate" class="form-control" />
                                </div>
                            </div>

                            <div class="showImageUpdateModal">
                                
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">লেখক</label>
                                    <input type="text" id="bookWriterUpdate" class="form-control" />
                                </div>
                            
                                <div class="form-group col">
                                    <label>ক্যাটাগরি</label>
                                    <select id="bookCatagoryUpdate" class="form-control">
                                        <option selected>ক্যাটাগরি...</option>
                                        <?php $__currentLoopData = $bishoy_name_update; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bishoy_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($bishoy_name->bishoyName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            <h2 class="d-none" id="getUpdateDataID"></h2>

                            <div class="modal-footer">
                                <div class="d-none" id="warningUpdate">
                                    <p style="color: red">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        দুঃখিত। আপনি কোনো ডাটা আপডেট করেননি ।
                                    </p>
                                </div>
                                <div width="100%" class="d-none" id="SuccessUpdate">
                                    <p style="color: green">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        আপডেট সফল হয়েছে ।
                                    </p>
                                </div>
                                <div class="flexLeft">
                                    <button data-id="" id="bookFairUpdateBtn" type="button" class="get btn btn-success">Update</button>
                                    <button onclick="$('#updateBookFairModal').modal('hide')" type="button" class="btn btn-primary" data-mdb-dismiss="modal">
                                        Cancle
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        





        
        <div class="modal fade" id="bookFairDeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <h2 class="p-3">Are you sure you want to delete this data?</h2>
                        <h2 class="d-none" id="bookFairDeleteIDget"></h2>
                    </div>
                    <div class="modal-footer">
                        <button data-id="" id="bookFairDeleteIDwork" type="button" class="get btn btn-danger">Delete</button>
                        <button onclick="$('#bookFairDeleteModal').modal('hide')" type="button" class="btn btn-success" data-mdb-dismiss="modal">
                            Cancle
                        </button>
                    </div>
                </div>
            </div>
        </div>
        


        <!-- Book Fair sorry modal -->
        <div class="modal fade" id="sorryMessege" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <button onclick="$('#sorryMessege').modal('hide')" type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close" ></button>
                    </div>
                    <div class="modal-body sorry-modal-body">

                    </div>
                    <div class="modal-footer">
                        <button type="button" id="refreshBookFairPage" class="btn btn-secondary" data-mdb-dismiss="modal">
                        Try Again
                        </button>
                        <button onclick="$('#sorryMessege').modal('hide')" type="button" class="btn btn-primary">Cancle</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Book Fair sorry modal -->


    </main>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

<script>
    getBookFairData();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/adminBookFair.blade.php ENDPATH**/ ?>