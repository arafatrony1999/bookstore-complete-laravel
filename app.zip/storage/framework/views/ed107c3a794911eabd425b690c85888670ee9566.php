
<?php $__env->startSection('content'); ?>
    <main class="admin_main">
        <div class="d-flex justify-content-center bs-spinner">
            <div class="spinner-border bs-spinner-border" role="status">
              <span class="sr-only">Loading...</span>
            </div>
        </div>

        <div class="addNewButton">
            <button id="addNewcatagory2" class="btn btn-primary">Add New</button>
        </div>

        <table class="table" id="catagory2userTable">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Book Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Image</th>
                    <th scope="col">Prokashoni</th>
                    <th scope="col">Writer</th>
                    <th scope="col">Catagory</th>
                    <th scope="col">Update</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>


            <tbody id="catagory2TR">

            </tbody>
            
        </table>




        
        <!-- Modal -->
        <div class="modal fade" id="addNewcatagory2Modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <h2 class="p-3">Add New item</h2>
                        
                        <form id="catagory2form_id" enctype="multipart/form-data">
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">বইয়ের নাম</label>
                                    <input type="text" id="catagory2Name" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">দাম</label>
                                    <input type="text" id="catagory2Price" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">ছবি</label>
                                    <input type="file" id="catagory2Image" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">প্রকাশনী</label>
                                    <input type="text" id="catagory2Prokashoni" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">লেখক</label>
                                    <input type="text" id="catagory2Writer" class="form-control" />
                                </div>
                            
                                <div class="form-group col">
                                    <label>ক্যাটাগরি</label>
                                    <select id="catagory2Catagory" class="form-control">
                                        <option selected>ক্যাটাগরি...</option>
                                        <?php $__currentLoopData = $bishoy_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bishoy_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bishoy_name->bishoyName); ?>"><?php echo e($bishoy_name->bishoyName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            

                            <div class="modal-footer">
                                <div class="d-none">
                                    <p style="color: red">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        দুঃখিত। আবার চেষ্টা করুণ !
                                    </p>
                                </div>
                                <div width="100%" class="d-none">
                                    <p style="color: green">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        ডাটা সফল ভাবে ডাটাবেজে সংরক্ষিত করা হয়েছে ।
                                    </p>
                                </div>
                                <div class="flexLeft">
                                    <button data-id="" id="catagory2AddBtn" type="button" class="get btn btn-success">Add</button>
                                    <button onclick="$('#addNewcatagory2Modal').modal('hide')" type="button" class="btn btn-primary" data-mdb-dismiss="modal">
                                        Cancle
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>





                
        <!--Update Modal -->
        <div class="modal fade" id="updatecatagory2Modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <h2 class="p-3">Add New item</h2>
                        
                        <form enctype="multipart/form-data">
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">বইয়ের নাম</label>
                                    <input type="text" id="catagory2NameUpdate" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">দাম</label>
                                    <input type="text" id="catagory2PriceUpdate" class="form-control" />
                                </div>
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">ছবি</label>
                                    <input type="file" id="catagory2ImageUpdate" class="form-control" />
                                </div>
                            
                                <div class="col">
                                    <label class="form-label">প্রকাশনী</label>
                                    <input type="text" id="catagory2ProkashoniUpdate" class="form-control" />
                                </div>
                            </div>

                            <div class="showImageUpdateModal">
                                
                            </div>
                            
                            <div class="row my-3">
                                <div class="col">
                                    <label class="form-label">লেখক</label>
                                    <input type="text" id="catagory2WriterUpdate" class="form-control" />
                                </div>
                            
                                <div class="form-group col">
                                    <label>ক্যাটাগরি</label>
                                    <select id="catagory2CatagoryUpdate" class="form-control">
                                        <option selected>ক্যাটাগরি...</option>
                                        <?php $__currentLoopData = $bishoy_name_update; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bishoy_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($bishoy_name->bishoyName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            <h2 class="d-none" id="getcatagory2UpdateDataID"></h2>

                            <div class="modal-footer">
                                <div class="d-none" id="warningcatagory2Update">
                                    <p style="color: red">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        দুঃখিত। আপনি কোনো ডাটা আপডেট করেননি ।
                                    </p>
                                </div>
                                <div width="100%" class="d-none" id="Successcatagory2Update">
                                    <p style="color: green">
                                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        আপডেট সফল হয়েছে ।
                                    </p>
                                </div>
                                <div class="flexLeft">
                                    <button data-id="" id="catagory2UpdateBtn" type="button" class="get btn btn-success">Update</button>
                                    <button onclick="$('#updatecatagory2Modal').modal('hide')" type="button" class="btn btn-primary" data-mdb-dismiss="modal">
                                        Cancle
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        





        
        <div class="modal fade" id="catagory2DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <h2 class="p-3">Are you sure you want to delete this data?</h2>
                        <h2 class="d-none" id="catagory2DeleteIDget"></h2>
                    </div>
                    <div class="modal-footer">
                        <button data-id="" id="catagory2DeleteIDwork" type="button" class="get btn btn-danger">Delete</button>
                        <button onclick="$('#catagory2DeleteModal').modal('hide')" type="button" class="btn btn-success" data-mdb-dismiss="modal">
                            Cancle
                        </button>
                    </div>
                </div>
            </div>
        </div>
        


        <!-- Catagory2 sorry modal -->
        <div class="modal fade" id="catagory2sorryMessege" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <button onclick="$('#catagory2sorryMessege').modal('hide')" type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close" ></button>
                    </div>
                    <div class="modal-body sorry-modal-body">

                    </div>
                    <div class="modal-footer">
                        <button type="button" id="refreshcatagory2Page" class="btn btn-secondary" data-mdb-dismiss="modal">
                        Try Again
                        </button>
                        <button onclick="$('#catagory2sorryMessege').modal('hide')" type="button" class="btn btn-primary">Cancle</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Catagory2 sorry modal -->


    </main>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

<script>
    getcatagory2Data();


    function getcatagory2Data(){
    $('#catagory2UpdateBtn').html("Update");
    $('#catagory2DeleteIDwork').html("Delete");
    
    axios.get('/getcatagory2Data')
    .then(function(response){

        var jsonData=response.data;

        $('#catagory2TR').empty();
        $.each(jsonData,function(i){
            $('<tr>').html(
            "<td>"+jsonData[i].id+"</td>"+
            "<td>"+jsonData[i].bookName+"</td>"+
            "<td>৳"+jsonData[i].bookPrice+".00</td>"+
            "<td><img width='50px' src='"+jsonData[i].catagory2Image+"'></td>"+
            "<td>"+jsonData[i].bookProkashoni+"</td>"+
            "<td>"+jsonData[i].bookWriter+"</td>"+
            "<td>"+jsonData[i].bookCatagory+"</td>"+
            "<td><button type='button' class='btn btn-success catchcatagory2UpdateID' id='catchcatagory2UpdateID' data-id="+jsonData[i].id+">"+"Update</button></td>"+
            "<td><button type='button' class='btn btn-danger catchcatagory2DeleteID' id='catchcatagory2DeleteID' data-id="+jsonData[i].id+">"+"Delete</button></td>"
            ).appendTo('#catagory2TR');
        });

        $('.bs-spinner').addClass('d-none');


        // append id for delete book fair item 
        $('.catchcatagory2DeleteID').on('click',function(){
            var deleteID = $(this).data('id');
            $('#catagory2DeleteModal').modal('show');
            $('#catagory2DeleteIDget').html(deleteID);
        });
        // append id for delete book fair item 


        
        // append id for update book fair item 
        $('.catchcatagory2UpdateID').on('click',function(){
            if(!$('#warningcatagory2Update').hasClass('d-none')){
                $('#warningcatagory2Update').addClass('d-none');
            }
            if(!$('#Successcatagory2Update').hasClass('d-none')){
                $('#Successcatagory2Update').addClass('d-none');
            }
            var updateIDget = $(this).data('id');
            var updateURL = '/catagory2UpdateURL';
            var updateID = {updateID:updateIDget};
            
            axios.post(updateURL,updateID)
            .then(function(response){
                var jsonDataUpdate = response.data;
                $('#catagory2NameUpdate').val(jsonDataUpdate[0].bookName);
                $('#catagory2PriceUpdate').val(jsonDataUpdate[0].bookPrice);
                $('#catagory2ProkashoniUpdate').val(jsonDataUpdate[0].bookProkashoni);
                $('#catagory2WriterUpdate').val(jsonDataUpdate[0].bookWriter);
                $('#catagory2CatagoryUpdate').val(jsonDataUpdate[0].bookCatagory);

                var updateImage = "<img height='80px' src='"+jsonDataUpdate[0].catagory2Image+"'>";
                $('.showImageUpdateModal').html(updateImage);
        
                $('#getcatagory2UpdateDataID').html(jsonDataUpdate[0].id);
                $('#updatecatagory2Modal').modal('show');
            })
            .catch(function(error){
                alert('fuck');
            });
        });
        // append id for update book fair item 

        $('#catagory2userTable').DataTable();
        $('.dataTables_length').addClass('bs-select');
        
    })
    .catch(function(error){
        var sorryModalText = "দুঃক্ষিত ! পেইজ রিফ্রেশ করুণ।";
        $('.sorry-modal-body').html(sorryModalText);
        $('#catagory2sorryMessege').modal('show');
    });
}

// Book fair delete item function 
$('#catagory2DeleteIDwork').on('click',function(){
    var deleteSpinner = "<div class='d-flex justify-content-center'><div class='spinner-border spinner-border-sm' role='status'></div></div>";
    $('#catagory2DeleteIDwork').html(deleteSpinner);


    var catagory2DeleteIDget = $('#catagory2DeleteIDget').html();

    var catagory2DeleteID = {catagory2DeleteIDget:catagory2DeleteIDget}
    var catagory2DeleteURL = '/catagory2DeleteURL';

    axios.post(catagory2DeleteURL,catagory2DeleteID)
    .then(function(response){
        if(response.data==1){
            getcatagory2Data();
            $('#catagory2DeleteModal').modal('hide');
        }
        else{
            $('.modal-body').html("Something went wrong!");
        }
    })
    .catch(function(error){
        $('.modal-body').html("Something went wrong!");
    });
});


// Book Fair update function 
$('#catagory2UpdateBtn').on('click',function(){
    var updateSpinner = "<div class='d-flex justify-content-center'><div class='spinner-border spinner-border-sm' role='status'></div></div>";
    $('#catagory2UpdateBtn').html(updateSpinner);
    
    var catagory2UpdateIDget = $('#getcatagory2UpdateDataID').html();

    
    var bookNameUpdate = $('#catagory2NameUpdate').val();

    var bookPriceUpdate = $('#catagory2PriceUpdate').val();

    var catagory2ImageGetUpdate = $('#catagory2ImageUpdate').prop('files')[0];
    var catagory2ImageUpdate = new FormData();
    catagory2ImageUpdate.append('photoUpdate',catagory2ImageGetUpdate);

    var bookProkashoniUpdate = $('#catagory2ProkashoniUpdate').val();
    var bookWriterUpdate = $('#catagory2WriterUpdate').val();
    var bookCatagoryUpdate = $('#catagory2CatagoryUpdate').val();

    var catagory2FinalUpdateURL = '/catagory2FinalUpdateURL';
    var sendcatagory2Object = {
        catagory2UpdateID:catagory2UpdateIDget,
        bookNameUpdate:bookNameUpdate,
        bookPriceUpdate:bookPriceUpdate,
        bookProkashoniUpdate:bookProkashoniUpdate,
        bookWriterUpdate:bookWriterUpdate,
        bookCatagoryUpdate:bookCatagoryUpdate
    };


    axios.post(catagory2FinalUpdateURL,sendcatagory2Object)
    .then(function(response){
        if(response.data==1){
            if(catagory2ImageGetUpdate==null){
                $('#Successcatagory2Update').removeClass('d-none');
                $('#updatecatagory2Modal').modal('hide');
                getcatagory2Data();
            }
            else{
                var catagory2ImageFinalUpdateURL = '/catagory2ImageFinalUpdateURL';
                axios.post(catagory2ImageFinalUpdateURL,catagory2ImageUpdate)
                .then(function(response){
                    $('#Successcatagory2Update').removeClass('d-none');
                    $('#updatecatagory2Modal').modal('hide');
                    getcatagory2Data();
                })
                .catch(function(error){
                    alert('Image update failed!');
                });
            }
        }else{
            $('#warningcatagory2Update').removeClass('d-none');
            // $('#catagory2UpdateBtn').html("Update");
        }
    })
    .catch(function(error){
        $('#warningcatagory2Update').removeClass('d-none');
        // $('#catagory2UpdateBtn').html("Update");
    });
});
// Book Fair update function

$('#refreshcatagory2Page').on('click',function(){
    location.reload();
});




$(document).ready(function(){

$('#addNewcatagory2').on('click',()=>{
    $('#catagory2form_id').trigger("reset");
    $('#catagory2AddBtn').html("Add");
    $('#addNewcatagory2Modal').modal('show');
});


$('#catagory2AddBtn').on('click',()=>{
    var addNewSpinner = "<div class='d-flex justify-content-center'><div class='spinner-border spinner-border-sm' role='status'></div></div>";
    $('#catagory2AddBtn').html(addNewSpinner);


    var bookName1 = $('#catagory2Name').val();

    var bookPrice1 = $('#catagory2Price').val();

    var catagory2ImageGet = $('#catagory2Image').prop('files')[0];
    var catagory2Image = new FormData();
    catagory2Image.append('photo',catagory2ImageGet);

    var bookProkashoni1 = $('#catagory2Prokashoni').val();
    var bookWriter1 = $('#catagory2Writer').val();
    var bookCatagory1 = $('#catagory2Catagory').val();

    var catagory2Data = {bookName1:bookName1,bookPrice1:bookPrice1,bookProkashoni1:bookProkashoni1,bookWriter1:bookWriter1,bookCatagory1:bookCatagory1}
    var catagory2Url = '/catagory2AddNew';

    alert(bookCatagory1);
    

    axios.post(catagory2Url,catagory2Data)
    .then(function(response){
        if(response.data==1){
            // var checkAddImageExistence = Object.keys('photo').length;
            if(catagory2ImageGet==null){
                $('#addNewcatagory2Modal').modal('hide');
                getcatagory2Data();
            }
            else{
                var catagory2ImageUrl = '/catagory2ImageUrl';
                axios.post(catagory2ImageUrl,catagory2Image)
                .then(function(response){
                    if(response.data==1){
                        $('#addNewcatagory2Modal').modal('hide');
                        getcatagory2Data();
                    }
                })
                .catch(function(error){
                    alert("image upload failed");
                });
            }
            $('#addNewcatagory2Modal').modal('hide');
            getcatagory2Data();
        }
        else{
            $('#catagory2AddBtn').html("Add");
            $('#SuccessAdd').removeClass('d-none');
            getcatagory2Data();
        }
    })
    .catch(function(error){
        $('#catagory2AddBtn').html("Add");
        $('#SuccessAdd').removeClass('d-none');
        getcatagory2Data();
    });

});
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/adminCatagory2.blade.php ENDPATH**/ ?>