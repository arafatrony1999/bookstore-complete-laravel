

<?php $__env->startSection('content'); ?>

<section>
    <!-- Carousel wrapper -->
    <div id="carouselDarkVariant" class="carousel slide carousel-fade carousel-dark" data-mdb-ride="carousel">
        <!-- Indicators -->
        <div class="carousel-indicators">
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="0" class="active" aria-current="true"
                aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="1" aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="2" aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="3" aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="4" aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="5" aria-label="Slide 1"></button>
        </div>

        <!-- Inner -->
        <div class="carousel-inner">

            <!-- Single item -->
            <div class="carousel-item active">
                <img src="images/background.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption d-md-block">
                    <h3>Big
                        <span>Save</span>
                    </h3>
                    <p>Get flat
                        <span>10%</span> Cashback</p>
                    <a class="button2" href="product.html">Shop Now </a>
                </div>
            </div>

            <!-- Single item -->
            <div class="carousel-item">
                <img src="images/banner4.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption">
                    <h3>Healthy
                        <span>Saving</span>
                    </h3>
                    <p>Get Upto
                        <span>30%</span> Off</p>
                    <a class="button2" href="product.html">Shop Now </a>
                </div>
            </div>

            <!-- Single item -->
            <div class="carousel-item">
                <img src="images/banner4.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption">
                    <h3>Healthy
                        <span>Saving</span>
                    </h3>
                    <p>Get Upto
                        <span>30%</span> Off</p>
                    <a class="button2" href="product.html">Shop Now </a>
                </div>
            </div>
            <!-- Single item -->
            <div class="carousel-item">
                <img src="images/banner2.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption d-none d-md-block">
                    <h5>Third slide label</h5>
                    <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                </div>
            </div>
            <!-- Single item -->
            <div class="carousel-item">
                <img src="images/banner1.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption d-none d-md-block">
                    <h5>Third slide label</h5>
                    <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="images/background.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                </div>
            </div>
        </div>
        <!-- Inner -->

        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-mdb-target="#carouselDarkVariant"
            data-mdb-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="false"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-mdb-target="#carouselDarkVariant"
            data-mdb-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- Carousel wrapper -->
</section>


<section>
    <div class="support-section container">
        <div class="support-card">
            <div class="support-left">
                <i class="fas fa-phone-alt"></i>
            </div>
            <div class="support-right">
                <div class="support-right-p">
                    <p>24/7 COUSTOMER SERVICE</p>
                    <P>+88-01879-923-111</P>
                </div>
            </div>
        </div>
        
        <div class="support-card">
            <div class="support-left">
                <i class="fa fa-plane"></i>
            </div>
            <div class="support-right">
                <div class="support-right-p">
                    <p>FAST SHIPPING SERVICE</p>
                    <P>Country Wide!</P>
                </div>
            </div>
        </div>
        
        <div class="support-card">
            <div class="support-left">
                <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="support-right">
                <div class="support-right-p">
                    <p>EASY RETURN POLICY</p>
                    <P>Money back guarantee</P>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="top-product-section container">
        <div style="background: url(images/background_product1.png)" class="top-product-items">
            <div class="product-name">
                <h1>আনিসুল হকের বই</h1>
                <a href="">SHOP NOW <span><i class="fas fa-arrow-right"></i></span></a>
            </div>
        </div>
        <div style="background: url(images/background_product2.png)" class="top-product-items with-margin">
            <div class="product-name">
                <h1>আরিফ আজাদ</h1>
                <a href="">SHOP NOW <span><i class="fas fa-arrow-right"></i></span></a>
            </div>
        </div>
        <div style="background: url(images/background_product3.png)" class="top-product-items">
            <div class="product-name">
                <h1>কম্পিউটার প্রোগ্রামিং</h1>
                <a href="">SHOP NOW <span><i class="fas fa-arrow-right"></i></span></a>
            </div>
        </div>
    </div>
</section>

<section>

    <div class="products-main-section container">
        <div class="product-main-section-header">
            <span>বই মেলা ২০২০</span>
        </div>
    </div>
    

    <div class="container section-marginTop text-center">
        <div class="row m-2">
            <div id="one" class="owl-carousel mb-4 owl-theme">
                <?php $__currentLoopData = $bookfair; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookfair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- single card  -->
                    <div class="item m-1 card">
                        <div class="text-center">
                            <div class="product-display-img">
                                <img class="pImg" data-id="<?php echo e($bookfair->id); ?>" src="<?php echo e($bookfair->bookImage); ?>" alt="Card image cap">
            
                                <i class="fas fa-search openCartBookFair" data-id="<?php echo e($bookfair->id); ?>"></i>
                                <div class="product-cart-button">
                                    <a href="" class="big-cart" data-id="<?php echo e($bookfair->id); ?>">Add to cart </a>
                                    <a href="" class="small-cart"><i class="fas fa-bars"></i></a>
                                    
                                    <?php
                                        $sessionID = session()->getId();
                                        $wish = App\Models\wishList::where('userID','=',$sessionID)->where('bookID','=',$bookfair->id)->count();
                                    ?>
                                    <?php if($wish==1): ?>
                                        <a href="" class="small-cart small-wishlist active-wishlist" data-id="<?php echo e($bookfair->id); ?>"><i class="fas fa-heart"></i></a>
                                    <?php else: ?>
                                        <a href="" class="small-cart small-wishlist" data-id="<?php echo e($bookfair->id); ?>"><i class="fas fa-heart"></i></a>
                                    <?php endif; ?>
                            
                                </div>
                            </div>
                            <h5 class="card-title mt-4" data-id="<?php echo e($bookfair->id); ?>"><?php echo e($bookfair->bookName); ?></h5>
                            <h3 class="price-tag">৳ <span data-id="<?php echo e($bookfair->id); ?>" class="priceWithout"><?php echo e($bookfair->bookPrice); ?></span>.00</h3>
                        </div>
                    </div>
                    <!-- single card  -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="previousBtn">
                <i id="customPrevBtn" class="btn normal-btn fas fa-chevron-left"></i>
            </div>
            <div class="nextBtn">
                <i id="customNextBtn" class="btn normal-btn fas fa-chevron-right"></i>
            </div>

        </div>
    </div>
</section>


<section>

    <div class="products-main-section container">
        <div class="product-main-section-header">
            <span>উপন্যাস সমূহ</span>
        </div>
    </div>
    

    <div class="container section-marginTop text-center">
        <div class="row m-2">
            <div id="two" class="owl-carousel mb-4 owl-theme"> 
                <!-- single card  -->
                <div class="item m-1 card">
                    <div class="text-center">
                        <div class="product-display-img">
                            <img src="images/product1.png" alt="Card image cap">
                            <div class="product-cart-button">
                                <a href="" class="big-cart">Add to cart</a>
                                <a href="" class="small-cart"><i class="fas fa-bars"></i></a>
                                <a href="" class="small-cart"><i class="fas fa-heart"></i></a>
                            </div>
                        </div>
                        <h5 class="card-title mt-4">চাঁদের পাহাড়</h5>
                        <h3 class="price-tag">145.00 $</h3>
                    </div>
                </div>
                <!-- single card  -->
                <!-- single card  -->
                <div class="item m-1 card">
                    <div class="text-center">
                        <div class="product-display-img">
                            <img src="images/product2.png" alt="Card image cap">
                            <div class="product-cart-button">
                                <a href="" class="big-cart">Add to cart</a>
                                <a href="" class="small-cart"><i class="fas fa-bars"></i></a>
                                <a href="" class="small-cart"><i class="fas fa-heart"></i></a>
                            </div>
                        </div>
                        <h5 class="card-title mt-4">মেঘডুবি</h5>
                        <h3 class="price-tag">145.00 $</h3>
                    </div>
                </div>
                <!-- single card  -->
                <!-- single card  -->
                <div class="item m-1 card">
                    <div class="text-center">
                        <div class="product-display-img">
                            <img src="images/product3.png" alt="Card image cap">
                            <div class="product-cart-button">
                                <a href="" class="big-cart">Add to cart</a>
                                <a href="" class="small-cart"><i class="fas fa-bars"></i></a>
                                <a href="" class="small-cart"><i class="fas fa-heart"></i></a>
                            </div>
                        </div>
                        <h5 class="card-title mt-4">কমিউনিকেশন হ্যাকস</h5>
                        <h3 class="price-tag">145.00 $</h3>
                    </div>
                </div>
                <!-- single card  -->
                <!-- single card  -->
                <div class="item m-1 card">
                    <div class="text-center">
                        <div class="product-display-img">
                            <img src="images/product4.png" alt="Card image cap">
                            <div class="product-cart-button">
                                <a href="" class="big-cart">Add to cart</a>
                                <a href="" class="small-cart"><i class="fas fa-bars"></i></a>
                                <a href="" class="small-cart"><i class="fas fa-heart"></i></a>
                            </div>
                        </div>
                        <h5 class="card-title mt-4">লোকে কি বলবে</h5>
                        <h3 class="price-tag">145.00 $</h3>
                    </div>
                </div>
                <!-- single card  -->
                <!-- single card  -->
                <div class="item m-1 card">
                    <div class="text-center">
                        <div class="product-display-img">
                            <img src="images/product5.png" alt="Card image cap">
                            <div class="product-cart-button">
                                <a href="" class="big-cart">Add to cart</a>
                                <a href="" class="small-cart"><i class="fas fa-bars"></i></a>
                                <a href="" class="small-cart"><i class="fas fa-heart"></i></a>
                            </div>
                        </div>
                        <h5 class="card-title mt-4">পূর্বপুরুষ</h5>
                        <h3 class="price-tag">145.00 $</h3>
                    </div>
                </div>
                <!-- single card  -->
                <!-- single card  -->
                <div class="item m-1 card">
                    <div class="text-center">
                        <div class="product-display-img">
                            <img src="images/product6.png" alt="Card image cap">
                            <div class="product-cart-button">
                                <a href="" class="big-cart">Add to cart</a>
                                <a href="" class="small-cart"><i class="fas fa-bars"></i></a>
                                <a href="" class="small-cart"><i class="fas fa-heart"></i></a>
                            </div>
                        </div>
                        <h5 class="card-title mt-4">দ্য ফ্লিল্যান্সর লেগে থাকলে সাফল্য আসবেই</h5>
                        <h3 class="price-tag">145.00 $</h3>
                    </div>
                </div>
                <!-- single card  -->
            </div>

            <div class="previousBtn">
                <i id="customPrevBtn2" class="btn normal-btn fas fa-chevron-left"></i>
            </div>
            <div class="nextBtn">
                <i id="customNextBtn2" class="btn normal-btn fas fa-chevron-right"></i>
            </div>

        </div>
    </div>
</section>

<section>
    
    <div class="many-product-section container">
        <div class="col-md-4">

            <div class="products-main-section container">
                <div class="product-main-section-header">
                    <span>নতুন বই সমূহ</span>
                </div>
            </div>

            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
        </div>

        <div class="col-md-4">

            <div class="products-main-section container">
                <div class="product-main-section-header">
                    <span>সাপ্তাহিক সেরা বই সমূহ</span>
                </div>
            </div>

            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
        </div>

        <div class="col-md-4">

            <div class="products-main-section container">
                <div class="product-main-section-header">
                    <span>বেস্টসেলার বইসমূহ</span>
                </div>
            </div>

            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
        </div>
    </div>

</section>

<section class="devide-area">

</section>






<section class="customModal d-none">
    <div class="custom-modal-container">
        <div class="custom-modal-cross">
            <i class="fas fa-times"></i>
        </div>
        <div class="customModalSpinner">
            <div class="d-flex justify-content-center">
                <div class="spinner-border customModal-bs-spinner" role="status"></div>
            </div>
        </div>
        <div class="custom-modal-body d-none">
            <div class="modal-image">

            </div>
            <div class="modal-details d-none">
                <div class="details-alignment">
                    <div class="modal-product-name">

                    </div>
                    <div class="modal-product-price">

                    </div>
                    <div class="modal-cart-details">
                        <input type="number" name="" id="" value="1">
                        <button id="addCartCustomModal">Add to Cart</button>
                    </div>
                    <div class="modal-product-details">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <script>
        $('.openCartBookFair').on('click',function(){
            $('.customModal').removeClass('d-none');

            var bookFairCustomModalID = $(this).data('id');
            var bookFairCustomModalURL = '/bookFairCustomModal';
            var bookFairCustomModalObject = {customModalID:bookFairCustomModalID};
            axios.post(bookFairCustomModalURL,bookFairCustomModalObject)
            .then(function(response){
                var customModajsonData=response.data;

                $('#addCartCustomModal').attr('data-id',customModajsonData[0].id);
                
                $('.modal-image').html("<img src='"+customModajsonData[0].bookImage+"'>")
                $('.modal-product-name').html(customModajsonData[0].bookName);
                $('.modal-product-price').html(customModajsonData[0].bookPrice);
                $('.modal-product-details').html(
                    "Catagories : "+ 
                    customModajsonData[0].bookProkashoni + ", " +
                    customModajsonData[0].bookWriter + ", " +
                    customModajsonData[0].bookCatagory
                );

                $('.customModalSpinner').addClass('d-none');
                $('.modal-details').removeClass('d-none');
                $('.custom-modal-body').removeClass('d-none');
            })
            .catch(function(error){
                alert("Sorry! Something went wrong. Try again!");
            });
        });


        $('.custom-modal-cross').on('click',function(){
            $('.customModal').addClass('d-none');
            $('.modal-image').html("");
            $('.modal-product-name').html("");
            $('.modal-product-price').html("");
            $('.modal-product-details').html("");

            $('.customModalSpinner').removeClass('d-none');
            if(!$('.modal-details').hasClass('d-none')){
                $('.modal-details').addClass('d-none');
            }
        });
    </script>


<script>
    $('.small-wishlist').on('click',function(e){
        e.preventDefault();
        var wishDataIDcatch = $(this).data('id');
        var wishListObject = {wishDataID:wishDataIDcatch};
        
        if($(this).hasClass('active-wishlist')){
            var wishListURL = '/wishListDelete';
        }
        else{
            var wishListURL = '/wishListAdd';
        }
        axios.post(wishListURL,wishListObject)
        .then(function(response){
            if(response.status==200){
                var id = response.data;
                $('.small-wishlist[data-id='+id+']').toggleClass('active-wishlist');
            }
        })
        .catch(function(error){
            alert('fuck')
        });
    })
</script>


<script>
    $('.big-cart').on('click',function(e){
        e.preventDefault();
        var updateSpinner = "<div class='d-flex align-big-cart justify-content-center'><div class='spinner-border spinner-border-sm' role='status'></div></div>";
        var cartDataIDcatch = $(this).data('id');
        var cartItemName = $('.card-title[data-id='+cartDataIDcatch+']').html();
        var cartItemPrice = $('.priceWithout[data-id='+cartDataIDcatch+']').html();
        var cartItemImage = $('.pImg[data-id='+cartDataIDcatch+']').attr('src');
        $(this).html(updateSpinner);
        var cartListObject = {
            cartDataIDcatch:cartDataIDcatch,
            cartItemName:cartItemName,
            cartItemPrice:cartItemPrice,
            cartItemImage:cartItemImage
        };
        var cartURL = '/cartURL';
        axios.post(cartURL,cartListObject)
        .then(function(response){
            if(response.status==200){
                var fontAwesome = "<i style='padding-left:5px' class='fas fa-check'></i>";
                var id = response.data;
                $('.big-cart[data-id='+id+']').html("Add to Cart"+fontAwesome);
            }
        })
        .catch(function(error){

        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\arafat\blog\resources\views/HomePage.blade.php ENDPATH**/ ?>