<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/aos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/mdb.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/toaster.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/owl.carousel.min.css')); ?>">

    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bookfair.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/cart.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/checkout.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/my-account.css')); ?>">
    <!-- custom css -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    <link href="https://fonts.googleapis.com/css2?family=Gowun+Dodum&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous" />
</head>
<body>
    
<?php echo $__env->make('layouts.Menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->yieldContent('content'); ?>




<?php echo $__env->make('layouts.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script src="https://code.jquery.com/jquery-3.6.0.js"
integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="<?php echo e(URL::asset('js/bootstrap.min.j')); ?>s"></script>
<script src="<?php echo e(URL::asset('js/mdb.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/axios.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/aos.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/collapse.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/onHover.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/owl.carousel.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
<script src="https://code.jquery.com/jquery-migrate-3.3.2.js"></script>
<script src="https://kit.fontawesome.com/411c21c790.js" crossorigin="anonymous"></script>

<script>
    window.addEventListener("scroll", () => {
        document.querySelector("#menu-bar").classList.toggle("sticky", window.scrollY > 50)
    });
</script>

<script>
    $(document).ready(function(){
        $('#openSideBar').on('click',()=>{
            $('.side-bar').addClass('active-side-bar');
            $("body").css("overflow", "hidden");
        });
        $('.fa-times').on('click',()=>{
            $('.side-bar').removeClass('active-side-bar');
            $("body").css("overflow", "scroll");
        });
    })
</script>

<script>
    $(document).ready(function() {
        var one = $("#one");
        var two = $("#two");
    
        $('#customNextBtn').click(function() {
            one.trigger('next.owl.carousel');
        });
        $('#customPrevBtn').click(function() {
            one.trigger('prev.owl.carousel');
        });

        
        $('#customNextBtn2').click(function() {
            two.trigger('next.owl.carousel');
        });
        $('#customPrevBtn2').click(function() {
            two.trigger('prev.owl.carousel');
        });

        one.owlCarousel({
            autoplay:false,
            loop:false,
            // rewind: true,
            dot:true,
            autoplayHoverPause:true,
            autoplaySpeed:100,
            margin:10,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:5
                }
            }
        });
    
        two.owlCarousel({
            autoplay:false,
            loop:false,
            dot:true,
            autoplayHoverPause:true,
            autoplaySpeed:100,
            margin:10,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:5
                }
            }
        });
    });
</script>


<?php echo $__env->yieldContent('script'); ?>

</body>
</html><?php /**PATH C:\Users\asus\Desktop\arafat\blog\resources\views/layouts/MainLayout.blade.php ENDPATH**/ ?>