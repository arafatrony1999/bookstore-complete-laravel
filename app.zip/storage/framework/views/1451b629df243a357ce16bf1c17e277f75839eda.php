

<?php $__env->startSection('content'); ?>

<section>
    <div class="page-title">
        <h1>Cart</h1>
        <div class="page-dir">
            <span>home</span>
            <span> / </span>
            <span class="current-pag">Cart</span>
        </div>
    </div>
</section>


<section class="container">

    <?php if(session()->has('success')): ?>
        <div style="font-size: 16px" class="alert alert-primary" role="alert">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div style="font-size: 16px" class="alert alert-danger" role="alert">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>


    <table id="cart-table">
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">view</th>
                <th scope="col">product</th>
                <th scope="col">price</th>
                <th scope="col">quantity</th>
                <th scope="col">total</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $total=0;
            ?>
            <?php if(Cookie::get('uuid')==null): ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="Account"><i data-id="<?php echo e($cart->rowId); ?>" class="fas fa-times crossBtn"></i></td>
                        <td data-label="view"><img src="<?php echo e($cart->options->image); ?>" alt=""></td>
                        <td data-label="product"><?php echo e($cart->name); ?></td>
                        <td data-label="price">৳ <?php echo e($cart->price); ?>.00</td>
                        <td data-label="quantity">
                            <form action="/cartQtyUpdate" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="number" name="qty" value="<?php echo e($cart->qty); ?>">
                                <input type="hidden" name="rowId" value="<?php echo e($cart->rowId); ?>">
                                <button style="font-size: 12px" class="btn btn-info getRowID" data-id="<?php echo e($cart->rowId); ?>">Update</button>
                            </form>
                        </td>
                        <td data-label="total">৳ <?php echo e($cart->subtotal); ?>.00</td>
                    </tr>
                    <?php
                        $total+=$cart->subtotal;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-label="Account"><i data-id="<?php echo e($cart->productID); ?>" class="fas fa-times crossBtn"></i></td>
                    <td data-label="view"><img src="<?php echo e($cart->productImage); ?>" alt=""></td>
                    <td data-label="product"><?php echo e($cart->productName); ?></td>
                    <td data-label="price">৳ <?php echo e($cart->productPrice); ?>.00</td>

                    <td data-label="quantity">
                        <form action="/cartQtyUpdate" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="number" name="qty" value="<?php echo e($cart->productQty); ?>">
                            <input type="hidden" name="rowId" value="<?php echo e($cart->productID); ?>">
                            <input type="hidden" name="productPrice" value="<?php echo e($cart->productPrice); ?>">
                            <button style="font-size: 12px" class="btn btn-info getRowID" data-id="<?php echo e($cart->rowId); ?>">Update</button>
                        </form>
                    </td>

                    <td data-label="total">৳ <?php echo e($cart->subtotal); ?>.00</td>
                    <?php
                        $total+=$cart->subtotal;
                    ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<section class="container">
    <div class="cart-table-footer">
        <div class="table-footer-left">
            <input type="text" name="" id="" placeholder="coupon code">
            <button>apply coupon</button>
        </div>
        <div class="table-footer-right">
            <button>update cart</button>
        </div>
    </div>
</section>
<section class="container">
    <div class="cart-count1">
        <div class="this-section-header">
            <h1>Cart totals</h1>
        </div>
        <div class="cart-total-single-row">
            <div class="cart-total-left">
                <h3>Subtotal</h3>
            </div>
            <div class="cart-total-right">
                <h3>৳ <?php echo e($total); ?>.00</h3>
            </div>
        </div>

        <div class="cart-total-single-row">
            <div class="cart-total-left">
                <h3>Shipping</h3>
            </div>
            <div class="cart-total-right">
                <h3>flat rate: <span style="color: red;">৳ 45.00</span></h3>
                <h3>Estimate for <span style="font-weight: bolder;">Dhaka</span> . </h3>
                <button id="cart-total-collapse">Change address <span class="addChange"><i class="fas fa-truck"></i></span></button>
                
                <div class="before-click">
                    <select name="" id="">
                        <option value="">Afghanistan</option>
                        <option value="">Australia</option>
                        <option value="">England</option>
                        <option value="">America</option>
                        <option value="">Argentina</option>
                        <option value="" selected>Bangladesh</option>
                        <option value="">India</option>
                        <option value="">Pakistan</option>
                    </select>
                    <select name="" id="">
                        <option value="">Sylhet</option>
                        <option value="">Barisal</option>
                        <option value="">Noakhali</option>
                        <option value="">Rajsahi</option>
                        <option value="">Rangamati</option>
                        <option value="" selected>Dhaka</option>
                        <option value="">Comilla</option>
                        <option value="">Chittagong</option>
                        <option value="">Chandpur</option>
                    </select>
                    <input type="text"  name="" id="" placeholder="Town / City">
                    <input type="text" name="" id="" placeholder="Postcode / ZIP">
                    <button>Update Cart</button>
                </div>
            </div>
        </div>
        <div class="cart-total-single-row">
            <div class="cart-total-left">
                <h3>Total</h3>
            </div>
            <div class="cart-total-right">
                <h3>৳ <?php echo e($total+45); ?>.00</h3>
            </div>
        </div>
    </div>
</section>

<section class="container">
    <div class="cart-final-buttons">
        <div class="final-left">
            <a href="/checkout">Proceed to checkout</a>
        </div>
        <div class="final-right">
            <a href="">Continue shopping</a>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/cart.blade.php ENDPATH**/ ?>