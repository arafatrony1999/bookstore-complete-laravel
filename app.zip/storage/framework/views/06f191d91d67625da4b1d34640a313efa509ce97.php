

<?php $__env->startSection('content'); ?>

<section>
    <!-- Carousel wrapper -->
    <div id="carouselDarkVariant" class="carousel slide carousel-fade carousel-dark" data-mdb-ride="carousel">
        <!-- Indicators -->
        <div class="carousel-indicators">
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="0" class="active" aria-current="true"
                aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="1" aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="2" aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="3" aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="4" aria-label="Slide 1"></button>
            <button data-mdb-target="#carouselDarkVariant" data-mdb-slide-to="5" aria-label="Slide 1"></button>
        </div>

        <!-- Inner -->
        <div class="carousel-inner">

            <!-- Single item -->
            <div class="carousel-item active">
                <img src="images/background.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption d-md-block">
                    <h3>Big
                        <span>Save</span>
                    </h3>
                    <p>Get flat
                        <span>10%</span> Cashback</p>
                    <a class="button2" href="product.html">Shop Now </a>
                </div>
            </div>

            <!-- Single item -->
            <div class="carousel-item">
                <img src="images/banner4.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption">
                    <h3>Healthy
                        <span>Saving</span>
                    </h3>
                    <p>Get Upto
                        <span>30%</span> Off</p>
                    <a class="button2" href="product.html">Shop Now </a>
                </div>
            </div>

            <!-- Single item -->
            <div class="carousel-item">
                <img src="images/banner4.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption">
                    <h3>Healthy
                        <span>Saving</span>
                    </h3>
                    <p>Get Upto
                        <span>30%</span> Off</p>
                    <a class="button2" href="product.html">Shop Now </a>
                </div>
            </div>
            <!-- Single item -->
            <div class="carousel-item">
                <img src="images/banner2.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption d-none d-md-block">
                    <h5>Third slide label</h5>
                    <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                </div>
            </div>
            <!-- Single item -->
            <div class="carousel-item">
                <img src="images/banner1.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption d-none d-md-block">
                    <h5>Third slide label</h5>
                    <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="images/background.jpg" class="d-block w-100" alt="..." />
                <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                </div>
            </div>
        </div>
        <!-- Inner -->

        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-mdb-target="#carouselDarkVariant"
            data-mdb-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="false"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-mdb-target="#carouselDarkVariant"
            data-mdb-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- Carousel wrapper -->
</section>


<section>
    <div class="support-section container">
        <div class="support-card">
            <div class="support-left">
                <i class="fas fa-phone-alt"></i>
            </div>
            <div class="support-right">
                <div class="support-right-p">
                    <p>24/7 COUSTOMER SERVICE</p>
                    <P>+88-01879-923-111</P>
                </div>
            </div>
        </div>
        
        <div class="support-card">
            <div class="support-left">
                <i class="fa fa-plane"></i>
            </div>
            <div class="support-right">
                <div class="support-right-p">
                    <p>FAST SHIPPING SERVICE</p>
                    <P>Country Wide!</P>
                </div>
            </div>
        </div>
        
        <div class="support-card">
            <div class="support-left">
                <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="support-right">
                <div class="support-right-p">
                    <p>EASY RETURN POLICY</p>
                    <P>Money back guarantee</P>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="top-product-section container">
        <div style="background: url(images/background_product1.png)" class="top-product-items">
            <div class="product-name">
                <h1>আনিসুল হকের বই</h1>
                <a href="">SHOP NOW <span><i class="fas fa-arrow-right"></i></span></a>
            </div>
        </div>
        <div style="background: url(images/background_product2.png)" class="top-product-items with-margin">
            <div class="product-name">
                <h1>আরিফ আজাদ</h1>
                <a href="">SHOP NOW <span><i class="fas fa-arrow-right"></i></span></a>
            </div>
        </div>
        <div style="background: url(images/background_product3.png)" class="top-product-items">
            <div class="product-name">
                <h1>কম্পিউটার প্রোগ্রামিং</h1>
                <a href="">SHOP NOW <span><i class="fas fa-arrow-right"></i></span></a>
            </div>
        </div>
    </div>
</section>

<section class="container">
    <div class="all-available-catagories">
        <?php $__currentLoopData = $getCatagoriesBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getCatagoriesBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/catagory/বিষয়/<?php echo e($getCatagoriesBook->bishoyName); ?>">
                <span><?php echo e($getCatagoriesBook->bishoyName); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <a href="/catagory"><span>See More</span></a>
    </div>
</section>


<section>
    <div class="products-main-section container">
        <div class="product-main-section-header">
            <span>বই মেলা ২০২০</span>
        </div>
    </div>
    

    <div class="container section-marginTop text-center">
        <div class="row m-2">
            <div id="one" class="owl-carousel mb-4 owl-theme">
                <?php $__currentLoopData = $bookfair; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookfair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- single card  -->
                    <div class="item m-1 card">
                        <div class="text-center">
                            <div class="product-display-img">
                                <img class="pImg" data-id="<?php echo e($bookfair->id); ?>" src="<?php echo e($bookfair->productImage); ?>" alt="Card image cap">
            
                                <i class="fas fa-search openCartBookFair" data-id="<?php echo e($bookfair->id); ?>"></i>
                                <div class="product-cart-button">
                                    <a href="" class="big-cart" data-id="<?php echo e($bookfair->id); ?>">Add to cart </a>
                                    <a href="/product/product_id=<?php echo e($bookfair->id); ?>" class="small-cart"><i class="far fa-eye"></i></a>
                                    
                                    <?php
                                        if(Cookie::get('uuid')==null){
                                            $sessionID = session()->getId();
                                        }
                                        else{
                                            $sessionID = Cookie::get('uuid');
                                        }
                                        $wish = App\Models\wishList::where('sessionORcookie','=',$sessionID)->where('bookID','=',$bookfair->id)->count();
                                    ?>
                                    <?php if($wish==1): ?>
                                        <a href="" class="small-cart small-wishlist active-wishlist" data-id="<?php echo e($bookfair->id); ?>"><i class="fas fa-heart"></i></a>
                                    <?php else: ?>
                                        <a href="" class="small-cart small-wishlist" data-id="<?php echo e($bookfair->id); ?>"><i class="fas fa-heart"></i></a>
                                    <?php endif; ?>
                            
                                </div>
                            </div>
                            <h5 class="card-title mt-4" data-id="<?php echo e($bookfair->id); ?>"><?php echo e($bookfair->bookName); ?></h5>
                            <h3 class="price-tag">৳ <span data-id="<?php echo e($bookfair->id); ?>" class="priceWithout"><?php echo e($bookfair->bookPrice); ?></span>.00</h3>
                        </div>
                    </div>
                    <!-- single card  -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="previousBtn">
                <i id="customPrevBtn" class="btn normal-btn fas fa-chevron-left"></i>
            </div>
            <div class="nextBtn">
                <i id="customNextBtn" class="btn normal-btn fas fa-chevron-right"></i>
            </div>

        </div>
    </div>
</section>



<section class="container" style="padding-top: 10rem">
    <div class="all-available-catagories">
        <?php $__currentLoopData = $getProkashoniBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getProkashoniBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/catagory/প্রকাশনী/<?php echo e($getProkashoniBook->ProkashoniName); ?>">
                <span><?php echo e($getProkashoniBook->ProkashoniName); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <a href="/catagory"><span>See More</span></a>
    </div>
</section>


<section>

    <div class="products-main-section container">
        <div class="product-main-section-header">
            <span>উপন্যাস সমূহ</span>
        </div>
    </div>
    

    <div class="container section-marginTop text-center">
        <div class="row m-2">
            <div id="two" class="owl-carousel mb-4 owl-theme">
                <?php $__currentLoopData = $catagory2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- single card  -->
                    <div class="item m-1 card">
                        <div class="text-center">
                            <div class="product-display-img">
                                <img class="pImg" data-id="<?php echo e($catagory2->id); ?>" src="<?php echo e($catagory2->productImage); ?>" alt="Card image cap">
            
                                <i class="fas fa-search openCartBookFair" data-id="<?php echo e($catagory2->id); ?>"></i>
                                <div class="product-cart-button">
                                    <a href="" class="big-cart" data-id="<?php echo e($catagory2->id); ?>">Add to cart </a>
                                    <a href="/product/product_id=<?php echo e($catagory2->id); ?>" class="small-cart"><i class="far fa-eye"></i></a>
                                    
                                    <?php
                                        if(Cookie::get('uuid')==null){
                                            $sessionID = session()->getId();
                                        }
                                        else{
                                            $sessionID = Cookie::get('uuid');
                                        }
                                        $wish = App\Models\wishList::where('sessionORcookie','=',$sessionID)->where('bookID','=',$catagory2->id)->count();
                                    ?>
                                    <?php if($wish==1): ?>
                                        <a href="" class="small-cart small-wishlist active-wishlist" data-id="<?php echo e($catagory2->id); ?>"><i class="fas fa-heart"></i></a>
                                    <?php else: ?>
                                        <a href="" class="small-cart small-wishlist" data-id="<?php echo e($catagory2->id); ?>"><i class="fas fa-heart"></i></a>
                                    <?php endif; ?>
                            
                                </div>
                            </div>
                            <h5 class="card-title mt-4" data-id="<?php echo e($catagory2->id); ?>"><?php echo e($catagory2->bookName); ?></h5>
                            <h3 class="price-tag">৳ <span data-id="<?php echo e($catagory2->id); ?>" class="priceWithout"><?php echo e($catagory2->bookPrice); ?></span>.00</h3>
                        </div>
                    </div>
                    <!-- single card  -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="previousBtn">
                <i id="customPrevBtn2" class="btn normal-btn fas fa-chevron-left"></i>
            </div>
            <div class="nextBtn">
                <i id="customNextBtn2" class="btn normal-btn fas fa-chevron-right"></i>
            </div>

        </div>
    </div>
</section>




<section>

    <div class="products-main-section container">
        <div class="product-main-section-header">
            <span>ইংরেজি ভাষার বই</span>
        </div>
    </div>
    

    <div class="container section-marginTop text-center">
        <div class="row m-2">
            <div id="three" class="owl-carousel mb-4 owl-theme">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- single card  -->
                    <div class="item m-1 card">
                        <div class="text-center">
                            <div class="product-display-img">
                                <img class="pImg" data-id="<?php echo e($product->id); ?>" src="<?php echo e($product->productImage); ?>" alt="Card image cap">
            
                                <i class="fas fa-search openCartBookFair" data-id="<?php echo e($product->id); ?>"></i>
                                <div class="product-cart-button">
                                    <a href="" class="big-cart" data-id="<?php echo e($product->id); ?>">Add to cart </a>
                                    <a href="/product/product_id=<?php echo e($product->id); ?>" class="small-cart"><i class="far fa-eye"></i></a>
                                    
                                    <?php
                                        if(Cookie::get('uuid')==null){
                                            $sessionID = session()->getId();
                                        }
                                        else{
                                            $sessionID = Cookie::get('uuid');
                                        }
                                        $wish = App\Models\wishList::where('sessionORcookie','=',$sessionID)->where('bookID','=',$product->id)->count();
                                    ?>
                                    <?php if($wish==1): ?>
                                        <a href="" class="small-cart small-wishlist active-wishlist" data-id="<?php echo e($product->id); ?>"><i class="fas fa-heart"></i></a>
                                    <?php else: ?>
                                        <a href="" class="small-cart small-wishlist" data-id="<?php echo e($product->id); ?>"><i class="fas fa-heart"></i></a>
                                    <?php endif; ?>
                            
                                </div>
                            </div>
                            <h5 class="card-title mt-4" data-id="<?php echo e($product->id); ?>"><?php echo e($product->bookName); ?></h5>
                            <h3 class="price-tag">৳ <span data-id="<?php echo e($product->id); ?>" class="priceWithout"><?php echo e($product->bookPrice); ?></span>.00</h3>
                        </div>
                    </div>
                    <!-- single card  -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="previousBtn">
                <i id="customPrevBtn3" class="btn normal-btn fas fa-chevron-left"></i>
            </div>
            <div class="nextBtn">
                <i id="customNextBtn3" class="btn normal-btn fas fa-chevron-right"></i>
            </div>

        </div>
    </div>
</section>



<section>
    
    <div class="many-product-section container">
        <div class="col-md-4">

            <div class="products-main-section container">
                <div class="product-main-section-header">
                    <span>নতুন বই সমূহ</span>
                </div>
            </div>

            <?php $__currentLoopData = $newBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/product/product_id=<?php echo e($newBook->id); ?>" class="many-item-card">
                    <div class="many-item-card-image">
                        <img src="<?php echo e($newBook->productImage); ?>" alt="">
                    </div>
                    <div class="many-item-card-details">
                        <span class="many-item-name"><?php echo e($newBook->bookName); ?></span>
                        <span class="many-item-price">৳ <?php echo e($newBook->bookPrice); ?>.00</span>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>

        <div class="col-md-4">

            <div class="products-main-section container">
                <div class="product-main-section-header">
                    <span>সাপ্তাহিক সেরা বই সমূহ</span>
                </div>
            </div>

            <a href="#" class="many-item-card">
                <div class="many-item-card-image">
                    <img src="images/product1.png" alt="">
                </div>
                <div class="many-item-card-details">
                    <span class="many-item-name">বেলা ফুরাবার আগে</span>
                    <span class="many-item-price">৳ 245.00</span>
                </div>
            </a>
        </div>

        <div class="col-md-4">

            <div class="products-main-section container">
                <div class="product-main-section-header">
                    <span>বেস্টসেলার বইসমূহ</span>
                </div>
            </div>

            <?php $__currentLoopData = $mostSaleBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostSaleBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/product/product_id=<?php echo e($mostSaleBook->id); ?>" class="many-item-card">
                    <div class="many-item-card-image">
                        <img src="<?php echo e($mostSaleBook->productImage); ?>" alt="">
                    </div>
                    <div class="many-item-card-details">
                        <span class="many-item-name"><?php echo e($mostSaleBook->bookName); ?></span>
                        <span class="many-item-price">৳ <?php echo e($mostSaleBook->bookPrice); ?>.00</span>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

</section>

<section class="devide-area">

</section>







<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/HomePage.blade.php ENDPATH**/ ?>