

<?php $__env->startSection('content'); ?>


    <section>
        <div class="page-title">
            <h1>Checkout</h1>
            <div class="page-dir">
                <span>home</span>
                <span> / </span>
                <span class="current-pag">Checkout</span>
            </div>
        </div>
    </section>


    <section class="container">
        <div class="coupon-que">
            <p><span><i class="fas fa-square-full"></i>Have a coupon?</span><span id="entrCupn">Click here to enter your code</span></p>
        </div>
        <div class="open-that-coupon-h0">
            <div class="coupon-open-que">
                <p>If you have a coupon code, please apply it below.</p>
                <div class="coupon-field">
                    <input type="text" name="" placeholder="Coupon Code">
                    <button>Apply coupon</button>
                </div>
            </div>
        </div>
    </section>

    <section class="container">
        <div class="billing-address">
            <div class="address1">
                <h1>Billing Details</h1>

                <?php if(Cookie::has('uuid')): ?>
                    <?php $__currentLoopData = $profileInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profileInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                        <form id="myForm" autocomplete="off" method="post" action="/order">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" autocomplete="false" name="hidden">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="firstName">First Name</label>
                                    <input type="text" value="<?php echo e($profileInfo->userFirstName); ?>" name="firstName" class="form-control" id="firstName" placeholder="First Name">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="lastName">Last Name</label>
                                    <input type="text" value="<?php echo e($profileInfo->userLastName); ?>" name="lastName" class="form-control" id="lastName" placeholder="Last Name">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="Phone">Phone</label>
                                <input type="text" value="<?php echo e($profileInfo->userPhone); ?>" class="form-control" name="phoneNumber" id="phoneNumber" placeholder="Phone Number">
                            </div>
                            <div class="form-group">
                                <label for="Email">Email</label>
                                <input type="email" value="<?php echo e($profileInfo->userEmail); ?>" class="form-control" name="emailAddrs" id="emailAddr" placeholder="Email Address">
                            </div>

                            <div class="form-group">
                                <label for="CompanyName">Company name (optional)</label>
                                <input type="text" value="<?php echo e($profileInfo->userCompany); ?>" name="userCompany" class="form-control" id="CompanyName">
                            </div>
                            <div class="form-group">
                                <label for="countryName">Country</label>
                                <select style="font-size: 16px;background:white;" class="form-control" name="country">
                                    <option value="<?php echo e($profileInfo->userCountry); ?>" selected><?php echo e($profileInfo->userCountry); ?></option>
                                    <option value="">Select a Country...</option>
                                    <option value="Argentina">Argentina</option>
                                    <option value="Australia">Australia</option>
                                    <option value="England">England</option>
                                    <option value="USA">USA</option>
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="India">India</option>
                                    <option value="Pakistan">Pakistan</option>
                                    <option value="Srilanka">Srilanka</option>
                                    <option value="Afganistan">Afganistan</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Japan">Japan</option>
                                    <option value="Chaina">Chaina</option>
                                    <option value="UAE">UAE</option>
                                    <option value="Korea">Korea</option>
                                    <option value="Nepal">Nepal</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="streerAddr">Street address</label>
                                <input type="text" value="<?php echo e($profileInfo->userAddress); ?>" class="form-control" name="streetAddr" id="streerAddr" placeholder="House Number and street name">
                                <p></p>
                                <input type="text" value="<?php echo e($profileInfo->userStreetAddress); ?>" class="form-control" name="streetAddr2" id="streerAddr2" placeholder="Apartment, suite, unit etc. (optional)">
                            </div>
                            <div class="form-group">
                                <label for="districtName">District</label>
                                <select style="font-size: 16px;background:white;" class="form-control" name="District">
                                    <option value="<?php echo e($profileInfo->userDistrict); ?>" selected><?php echo e($profileInfo->userDistrict); ?></option>
                                    <option value="">Select District...</option>
                                    <option value="Barguna">Barguna</option>
                                    <option value="Barisal">Barisal</option>
                                    <option value="Bhola">Bhola</option>
                                    <option value="Jhalokati">Jhalokati</option>
                                    <option value="Patuakhali">Patuakhali</option>
                                    <option value="Brahmanbaria">Brahmanbaria</option>
                                    <option value="Chandpur">Chandpur</option>
                                    <option value="Chittagong">Chittagong</option>
                                    <option value="Dhaka">Dhaka</option>
                                    <option value="Comilla">Comilla</option>
                                    <option value="Noakhali">Noakhali</option>
                                    <option value="Feni">Feni</option>
                                    <option value="Gazipur">Gazipur</option>
                                    <option value="Munshiganj">Munshiganj</option>
                                    <option value="Narayanganj">Narayanganj</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="inputAddress2">Town / City</label>
                                <input type="text" value="<?php echo e($profileInfo->userTownCity); ?>" class="form-control" name="townOrCity" id="streerAddr3">
                            </div>

                            
                            <div class="form-group">
                                <label for="Postcode">Postcode / ZIP (optional)</label>
                                <input type="text" value="<?php echo e($profileInfo->userZip); ?>" class="form-control" name="zipCode" id="post-zip">
                            </div>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <form id="myForm" autocomplete="off" method="post" action="/order">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" autocomplete="false" name="hidden">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="firstName">First Name</label>
                                <input type="text" name="firstName" class="form-control" id="firstName" placeholder="First Name">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="lastName">Last Name</label>
                                <input type="text" name="lastName" class="form-control" id="lastName" placeholder="Last Name">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="Phone">Phone</label>
                            <input type="text" class="form-control" name="phoneNumber" id="phoneNumber" placeholder="Phone Number">
                        </div>
                        <div class="form-group">
                            <label for="Email">Email</label>
                            <input type="email" class="form-control" name="emailAddrs" id="emailAddr" placeholder="Email Address">
                        </div>

                        <div class="form-group">
                            <label for="CompanyName">Company name (optional)</label>
                            <input type="text" name="userCompany" class="form-control" id="CompanyName">
                        </div>
                        <div class="form-group">
                            <label for="countryName">Country</label>
                            <select style="font-size: 16px;background:white;" class="form-control" name="country">
                                <option value="">Select a Country...</option>
                                <option value="Argentina">Argentina</option>
                                <option value="Australia">Australia</option>
                                <option value="England">England</option>
                                <option value="USA">USA</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="India">India</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Srilanka">Srilanka</option>
                                <option value="Afganistan">Afganistan</option>
                                <option value="Canada">Canada</option>
                                <option value="Japan">Japan</option>
                                <option value="Chaina">Chaina</option>
                                <option value="UAE">UAE</option>
                                <option value="Korea">Korea</option>
                                <option value="Nepal">Nepal</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="streerAddr">Street address</label>
                            <input type="text" class="form-control" name="streetAddr" id="streerAddr" placeholder="House Number and street name">
                            <p></p>
                            <input type="text" class="form-control" name="streetAddr2" id="streerAddr2" placeholder="Apartment, suite, unit etc. (optional)">
                        </div>
                        <div class="form-group">
                            <label for="districtName">District</label>
                            <select style="font-size: 16px;background:white;" class="form-control" name="District">
                                <option value="">Select District...</option>
                                <option value="Barguna">Barguna</option>
                                <option value="Barisal">Barisal</option>
                                <option value="Bhola">Bhola</option>
                                <option value="Jhalokati">Jhalokati</option>
                                <option value="Patuakhali">Patuakhali</option>
                                <option value="Brahmanbaria">Brahmanbaria</option>
                                <option value="Chandpur">Chandpur</option>
                                <option value="Chittagong">Chittagong</option>
                                <option value="Dhaka">Dhaka</option>
                                <option value="Comilla">Comilla</option>
                                <option value="Noakhali">Noakhali</option>
                                <option value="Feni">Feni</option>
                                <option value="Gazipur">Gazipur</option>
                                <option value="Munshiganj">Munshiganj</option>
                                <option value="Narayanganj">Narayanganj</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="inputAddress2">Town / City</label>
                            <input type="text" class="form-control" name="townOrCity" id="streerAddr3">
                        </div>

                        
                        <div class="form-group">
                            <label for="Postcode">Postcode / ZIP (optional)</label>
                            <input type="text" class="form-control" name="zipCode" id="post-zip">
                        </div>
                    </form>
                <?php endif; ?>
            </div>


            
        </div>
    </section>

    
    <section class="container checkout-cart-space">

        <div class="cart-count1">
            <div class="this-section-header">
                <h1>Your Products in Cart</h1>
            </div>
        </div>
        
        <table id="cart-table">
            <thead>
                <tr>
                    <th scope="col"></th>
                    <th scope="col">view</th>
                    <th scope="col">product</th>
                    <th scope="col">price</th>
                    <th scope="col">quantity</th>
                    <th scope="col">total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $total=0;
                ?>
                <?php if(Cookie::get('uuid')==null): ?>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="Account"><i data-id="<?php echo e($cart->rowId); ?>" class="fas fa-times crossBtn"></i></td>
                            <td data-label="view"><img src="<?php echo e($cart->options->image); ?>" alt=""></td>
                            <td data-label="product"><?php echo e($cart->name); ?></td>
                            <td data-label="price">৳ <?php echo e($cart->price); ?>.00</td>
                            <td data-label="quantity">
                                <form action="/cartQtyUpdate" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="number" name="qty" value="<?php echo e($cart->qty); ?>">
                                    <input type="hidden" name="rowId" value="<?php echo e($cart->rowId); ?>">
                                    <button style="font-size: 12px" class="btn btn-info getRowID" data-id="<?php echo e($cart->rowId); ?>">Update</button>
                                </form>
                            </td>
                            <td data-label="total">৳ <?php echo e($cart->subtotal); ?>.00</td>
                        </tr>
                        <?php
                            $total+=$cart->subtotal;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="Account"><i data-id="<?php echo e($cart->productID); ?>" class="fas fa-times crossBtn"></i></td>
                        <td data-label="view"><img src="<?php echo e($cart->productImage); ?>" alt=""></td>
                        <td data-label="product"><?php echo e($cart->productName); ?></td>
                        <td data-label="price">৳ <?php echo e($cart->productPrice); ?>.00</td>

                        <td data-label="quantity">
                            <form action="/cartQtyUpdate" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="number" name="qty" value="<?php echo e($cart->productQty); ?>">
                                <input type="hidden" name="rowId" value="<?php echo e($cart->productID); ?>">
                                <input type="hidden" name="productPrice" value="<?php echo e($cart->productPrice); ?>">
                                <button style="font-size: 12px" class="btn btn-info getRowID" data-id="<?php echo e($cart->rowId); ?>">Update</button>
                            </form>
                        </td>

                        <td data-label="total">৳ <?php echo e($cart->subtotal); ?>.00</td>
                        <?php
                            $total+=$cart->subtotal;
                        ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </section>

        
    <section class="container">
        <div class="cart-count1">
            <div class="this-section-header">
                <h1>Order Summery</h1>
            </div>

            <div class="cart-total-single-row">
                <div class="cart-total-left">
                    <h3>Product</h3>
                </div>
                <div class="cart-total-right">
                    <h3>Total</h3>
                </div>
            </div>

            <?php
                $finalSubtotal = 0;
            ?>
            <?php if(Cookie::has('uuid')): ?>
                <?php $__currentLoopData = $cartSummery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartSummery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cart-total-single-row">
                        <div class="cart-total-left">
                            <h4><?php echo e($cartSummery->productName); ?>  × <?php echo e($cartSummery->productQty); ?></h4>
                        </div>
                        <div class="cart-total-right">
                            <h3><span style="color: red;">৳ <?php echo e($cartSummery->productPrice*$cartSummery->productQty); ?>.00</span></h3>
                        </div>
                    </div>
                    <?php
                        $finalSubtotal+=$cartSummery->subtotal;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $cartSummery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartSummery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cart-total-single-row">
                        <div class="cart-total-left">
                            <h4><?php echo e($cartSummery->name); ?>  × <?php echo e($cartSummery->qty); ?></h4>
                        </div>
                        <div class="cart-total-right">
                            <h3><span style="color: red;">৳ <?php echo e($cartSummery->price*$cartSummery->qty); ?>.00</span></h3>
                        </div>
                    </div>
                    <?php
                        $finalSubtotal+=$cartSummery->subtotal;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <div class="cart-total-single-row">
                <div class="cart-total-left">
                    <h3>Subtotal</h3>
                </div>
                <div class="cart-total-right">
                    <h3>৳ <?php echo e($finalSubtotal); ?>.00</h3>
                </div>
            </div>
            <div class="cart-total-single-row">
                <div class="cart-total-left">
                    <h3>Shipping</h3>
                </div>
                <div class="cart-total-right">
                    <h3>flat rate: <span style="color: green;">৳ 45.00</span></h3>
                </div>
            </div>
            <div class="cart-total-single-row">
                <div class="cart-total-left">
                    <h3>Total</h3>
                </div>
                <div class="cart-total-right">
                    <h3>৳ <?php echo e($finalSubtotal+45); ?>.00</h3>
                </div>
            </div>
        </div>
    </section>

    <section class="container checkout-cart-space">
        <div class="payment-section">
            <h2>Cash on Delievery</h2>
            <div class="payCash">
                Pay with cash upon delivery.
            </div>
            <div class="hr">
                <hr>
            </div>
            <p>Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our privacy policy.</p>
            <div class="cash-btn">
                <button type="submit" form="myForm" style="font-size: 16px;padding:10px 20px" class="btn btn-info">Place Order</button>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/checkout.blade.php ENDPATH**/ ?>