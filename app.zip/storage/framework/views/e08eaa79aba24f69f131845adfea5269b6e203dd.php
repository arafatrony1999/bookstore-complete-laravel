

<?php $__env->startSection('content'); ?>

<section class="container">
    <div class="flex-container">
        <div class="inside-left">
            <h2 class="heading-left">browse books</h2>
            <div class="browse-books">
                <?php $__currentLoopData = $bishoyName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bishoyName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="browse-books-items">
                        <a href="/catagory/<?php echo e($bishoyName->bishoyName); ?>" style="font-size: 14px"><i class="fas fa-book fa-rotate-45"></i><?php echo e($bishoyName->bishoyName); ?></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        <div class="inside-right">
            <h1 style="padding-top:30px">
                <?php echo e($data); ?>

            </h1>
            <div class="inside-right-headings">
                <div class="right-heading">
                    <h3>showing 1-10 of <?php echo e($count); ?> items</h3>
                    <select name="" id="">
                        <option value="">Sort by popularity</option>
                        <option value="">Sort by average rating</option>
                        <option value="">Sort by latest</option>
                        <option value="">Sort by price:low to high</option>
                        <option value="">Sort by price:low to high</option>
                    </select>
                </div>

                <div class="left-heading">
                    <div id="grid-icon" class="collapse-options active-icon">
                        <i class="fas fa-th-large icon-active"></i>
                    </div>
                    <div id="list-icon" class="collapse-options">
                        <i class="fas fa-list"></i>
                    </div>
                </div>
            </div>

            <div class="right-items">
                <?php $__currentLoopData = $bookCatagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCatagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="right-items-single-card">
                        <div class="product-display-img">
                            <img src="<?php echo e($bookCatagory->productImage); ?>" alt="Card image cap">
                            <div class="product-cart-button">
                                <a href="/product/product_id=<?php echo e($bookCatagory->id); ?>" class="big-cart2">Quick View</a>
                                <a href="" class="small-cart2"><i class="fas fa-bars"></i></a>
                                <a href="" class="small-cart2"><i class="fas fa-heart"></i></a>
                            </div>
                        </div>
                        <div class="name-and-price">
                            <h5 class="card-title mt-4"><?php echo e($bookCatagory->bookName); ?></h5>
                            <h3 class="price-tag"><?php echo e($bookCatagory->bookWriter); ?></h3>
                            <h3 class="price-tag">৳ <?php echo e($bookCatagory->bookPrice); ?>.00</h3>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="pagination-section">
                <div class="pagination-buttons">
                    <div class="pag-btn">
                        <a href="#" class="active-pag">1</a>
                    </div>
                    <div class="pag-btn">
                        <a href="#">2</a>
                    </div>
                    <div class="pag-btn">
                        <a href="#">3</a>
                    </div>
                    <div class="pag-btn">
                        <span style="font-size: 2rem;">....</span>
                    </div>
                    <div class="pag-btn">
                        <a href="#">Next</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/catagory_bishoy.blade.php ENDPATH**/ ?>