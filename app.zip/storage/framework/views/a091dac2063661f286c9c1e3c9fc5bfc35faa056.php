

<?php $__env->startSection('content'); ?>

<div class="container section-marginTop text-center">
    <div class="row m-2">
        <div id="two" class="owl-carousel mb-4 owl-theme amar-sob">
            <?php
                if(Cookie::get('uuid')==null){
                    $sessionID = session()->getId();
                }
                else{
                    $sessionID = Cookie::get('uuid');
                }
                
            ?>
            <?php if(1==1): ?>
                <a href="" class="small-cart small-wishlist active-wishlist" data-id="$catagory2->id"><i class="fas fa-heart"></i></a>
            <?php else: ?>
                <a href="" class="small-cart small-wishlist" data-id="$catagory2->id"><i class="fas fa-heart"></i></a>
            <?php endif; ?>
    
                <!-- single card  -->
                <!-- single card  -->
        </div>

        <div class="previousBtn">
            <i id="customPrevBtn2" class="btn normal-btn fas fa-chevron-left"></i>
        </div>
        <div class="nextBtn">
            <i id="customNextBtn2" class="btn normal-btn fas fa-chevron-right"></i>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    loadItem();
    
    function loadItem(){
        var a = <?php echo "fuck";?>
        alert(a);
        axios.get('/m')
        .then(function(response){

            var jsonData = response.data;

            $.each(jsonData,function(i){
                $("<div class='owl-stage-outer'><div class='owl-stage' style='transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1381px;'><div class='owl-item active' style='width: 335.2px; margin-right: 10px;'>").html(
                        "<div class='text-center'>"+
                            "<div class='product-display-img'>"+
                                "<img class='pImg' data-id='"+jsonData[i].id+"' src='"+jsonData[i].productImage+"' alt='Card image cap'>"+

                                "<i class='fas fa-search openCartBookFair' data-id='"+jsonData[i].id+"'></i>"+
                                "<div class='product-cart-button'>"+
                                    "<a href='' class='big-cart' data-id='"+jsonData[i].id+"'>Add to cart </a>"+
                                    "<a href='/product/product_id="+jsonData[i].id+"' class='small-cart'><i class='far fa-eye'></i></a>"+
                                "</div>"+
                            "</div>"+
                            "<h5 class='card-title mt-4' data-id='"+jsonData[i].id+"'>"+jsonData[i].bookName+"</h5>"+
                            "<h3 class='price-tag'>৳ <span data-id='"+jsonData[i].id+"' class='priceWithout'>"+jsonData[i].bookPrice+"</span>.00</h3>"+
                        "</div>"+
                        var a = <?php echo e('fuck'); ?>;
                        alert(a)
                        $wish = App\Models\wishList::where('sessionORcookie','=',$sessionID)->where('bookID','=',jsonData[i].id)->count();
                ).appendTo('.amar-sob');
            });
        })
        .catch(function(error){
            alert('hello world')
        });
    }


    
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Laravel Projects\arafat\blog\resources\views/a.blade.php ENDPATH**/ ?>