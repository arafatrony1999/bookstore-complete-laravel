<?php

namespace App\Http\Controllers;

use App\Models\bishoy_name;
use Illuminate\Http\Request;
use App\Models\wishList;
use App\Models\Cart_modal;
use App\Models\product_modal;
use App\Models\prokashoni_name;
use App\Models\reg;
use App\Models\review;
use App\Models\review_reaction;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Artisan;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Support\Facades\Cookie;

class cartController extends Controller
{
    
}
