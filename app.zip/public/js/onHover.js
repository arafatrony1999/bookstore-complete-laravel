$(document).ready(function(){
    $('#lekhok').mouseenter(function(){
        $('.hover-lekhok').css('display','block')
    })
    $('#lekhok').mouseleave(function(){
        $('.hover-lekhok').css('display','none')
    });

    
    $('#prokashoni').mouseenter(function(){
        $('.hover-prokashoni').css('display','block')
    })
    $('#prokashoni').mouseleave(function(){
        $('.hover-prokashoni').css('display','none')
    });

    
    $('#bishoy').mouseenter(function(){
        $('.hover-bishoy').css('display','block')
    })
    $('#bishoy').mouseleave(function(){
        $('.hover-bishoy').css('display','none')
    });
});